module.exports = require("./lib/_stream_writable.js")
