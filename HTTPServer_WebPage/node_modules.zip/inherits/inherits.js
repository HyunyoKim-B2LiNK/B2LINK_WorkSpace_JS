module.exports = require('util').inherits
